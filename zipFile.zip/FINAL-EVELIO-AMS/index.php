<?php
include "pdo_functions.php";
include "session.php";
$pdo = new pdoCRUD();

if(isset($_POST['login'])){
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $user = $pdo->login($email,$password);
    if($user){
        login_user($user);
        if($user['first_login_required']){
            header('Location: change_password.php');
            exit;
        }
        if($user['role']==='admin') header('Location: admin_dashboard.php');
        elseif($user['role']==='teacher') header('Location: teacher_dashboard.php');
        else header('Location: student_dashboard.php');
        exit;
    }
    $error = "Invalid credentials";
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>AMS Login</title>
    <style>
        body{font-family: Arial, sans-serif;}
        .container{max-width:420px;margin:40px auto;border:1px solid #ddd;padding:20px;border-radius:8px;}
        input{width:100%;padding:10px;margin:8px 0;}
        button{padding:10px 14px;}
        .actions{display:flex;justify-content:space-between;align-items:center;margin-top:10px;}
    </style>
    <script>
        function applyNewStudent(){
            window.location.href = 'apply_consent.php';
        }
    </script>
</head>
<body>
    <div class="container">
        <h2>Academic Management System</h2>
        <?php if(isset($error)){ echo '<div style="color:red;">'.htmlspecialchars($error,ENT_QUOTES,'UTF-8').'</div>'; } ?>
        <form method="post">
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <div class="actions">
                <button name="login">Login</button>
                <button type="button" onclick="applyNewStudent()">Apply as new student</button>
            </div>
        </form>
    </div>
</body>
</html>

