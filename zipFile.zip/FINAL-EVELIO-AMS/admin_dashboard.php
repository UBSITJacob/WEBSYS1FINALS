<?php
include "session.php";
require_login();
if($_SESSION['role']!=='admin'){ header('Location: index.php'); exit; }
include "dbconfig.php";
$total_students = (int)$pdo->query("SELECT COUNT(*) c FROM students")->fetch()['c'];
$total_teachers = (int)$pdo->query("SELECT COUNT(*) c FROM teachers")->fetch()['c'];
$pending_applicants = (int)$pdo->query("SELECT COUNT(*) c FROM applicants WHERE status='pending'")->fetch()['c'];
$enrolled_this_year = (int)$pdo->query("SELECT COUNT(*) c FROM enrollments WHERE school_year = YEAR(CURDATE())")->fetch()['c'];
$by_grade = $pdo->query("SELECT grade_level, COUNT(*) c FROM students GROUP BY grade_level")->fetchAll();
$by_strand = $pdo->query("SELECT strand, COUNT(*) c FROM students WHERE strand IS NOT NULL GROUP BY strand")->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Dashboard</title>
    <style>
        body{font-family: Arial, sans-serif;}
        .container{max-width:1000px;margin:20px auto;}
        .cards{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;}
        .card{border:1px solid #ddd;padding:12px;border-radius:8px;text-align:center;}
        table{width:100%;border-collapse:collapse;margin-top:20px;}
        th,td{border:1px solid #ddd;padding:8px;}
    </style>
</head>
<body>
<div class="container">
    <h3>Welcome, <?php echo htmlspecialchars($_SESSION['email'],ENT_QUOTES,'UTF-8'); ?></h3>
    <div class="cards">
        <div class="card">Total Students<br><strong><?php echo $total_students; ?></strong></div>
        <div class="card">Total Teachers<br><strong><?php echo $total_teachers; ?></strong></div>
        <div class="card">Applicants Pending<br><strong><?php echo $pending_applicants; ?></strong></div>
        <div class="card">Enrolled This Year<br><strong><?php echo $enrolled_this_year; ?></strong></div>
    </div>
    <h4>Counts by Grade</h4>
    <table>
        <tr><th>Grade Level</th><th>Count</th></tr>
        <?php foreach($by_grade as $g){ echo '<tr><td>'.htmlspecialchars($g['grade_level'],ENT_QUOTES,'UTF-8').'</td><td>'.$g['c'].'</td></tr>'; } ?>
    </table>
    <h4>Counts by Strand</h4>
    <table>
        <tr><th>Strand</th><th>Count</th></tr>
        <?php foreach($by_strand as $s){ echo '<tr><td>'.htmlspecialchars($s['strand'],ENT_QUOTES,'UTF-8').'</td><td>'.$s['c'].'</td></tr>'; } ?>
    </table>
    <p><a href="applicants.php">Applicants</a> | <a href="sections.php">Manage Sections</a> | <a href="teachers.php">Manage Teachers</a> | <a href="students.php">Manage Students</a> | <a href="subject_loads.php">Subject Loads</a> | <a href="assign_section.php">Assign Section</a> | <a href="manage_enrollment.php">Manage Enrollment</a></p>
</div>
</body>
</html>
